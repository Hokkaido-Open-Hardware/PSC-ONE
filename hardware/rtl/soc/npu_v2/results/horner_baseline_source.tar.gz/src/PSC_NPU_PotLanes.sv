`timescale 1ns/1ps

// Exponent is TIME (7..0), never an activation shift amount.
// SERIAL_TERMS=0: one Horner step/exponent, coefficient 0,+/-1,+/-2.
// SERIAL_TERMS=1: two steps/exponent, each contribution only 0,+/-x.
// Product is separate from persistent ACC so previous batches are not doubled.
module PSC_NPU_PotLanes #(
    parameter integer LANES = 4,
    parameter integer SERIAL_TERMS = 0
) (
    input wire clock, reset_n, capture, issue, phase,
    input wire [2:0] exponent,
    input wire [1:0] group_index,
    input wire signed_mode,
    input wire [127:0] data_A, data_B,
    output reg [LANES-1:0] wb_valid,
    output wire [LANES*4-1:0] wb_id,
    output wire [LANES*32-1:0] wb_data
);
    reg [127:0] a_snapshot, b_snapshot;
    wire final_step = exponent == 3'd0 && (!SERIAL_TERMS || phase);
    always @(posedge clock or negedge reset_n) begin
        if (!reset_n) begin
            a_snapshot <= 0;
            b_snapshot <= 0;
            wb_valid <= 0;
        end else begin
            if (capture) begin
                a_snapshot <= data_A;
                b_snapshot <= data_B;
            end
            wb_valid <= {LANES{issue && final_step}};
        end
    end
    genvar lane, group;
    generate for (lane=0; lane<LANES; lane=lane+1) begin : GEN_LANE
        localparam [3:0] LANE_ID = lane;
        wire [(16/LANES)*8-1:0] lane_a, lane_b;
        for (group=0; group<16/LANES; group=group+1) begin : GEN_OPERANDS
            assign lane_a[group*8 +: 8] = a_snapshot[(group*LANES+lane)*8 +: 8];
            assign lane_b[group*8 +: 8] = b_snapshot[(group*LANES+lane)*8 +: 8];
        end
        wire [7:0] a, code;
        // Only the existing <=4:1 context mux remains; one context at 16 lanes.
        if (LANES == 16) begin : GEN_DIRECT
            assign a = lane_a[7:0];
            assign code = lane_b[7:0];
        end else if (LANES == 8) begin : GEN_TWO_CONTEXTS
            assign a = group_index[0] ? lane_a[15:8] : lane_a[7:0];
            assign code = group_index[0] ? lane_b[15:8] : lane_b[7:0];
        end else begin : GEN_FOUR_CONTEXTS
            assign a = lane_a[group_index*8 +: 8];
            assign code = lane_b[group_index*8 +: 8];
        end
        wire [8:0] x = {signed_mode && a[7], a};
        wire [9:0] contribution;
        wire first_step = exponent == 3'd7 && (!SERIAL_TERMS || !phase);
        reg [16:0] product;
        wire [16:0] feedback;
        if (SERIAL_TERMS) begin : GEN_SERIAL
            wire [3:0] nibble = phase ? code[7:4] : code[3:0];
            wire hit = (code != 8'd0) && (nibble[2:0] == exponent);
            wire [8:0] signed_x = nibble[3] ? -x : x;
            assign contribution = hit ? {signed_x[8],signed_x} : 10'd0;
            assign feedback = first_step ? 17'd0 :
                              (phase ? product : {product[15:0],1'b0});
        end else begin : GEN_MERGED
            wire hit0 = code[2:0] == exponent;
            wire hit1 = code[6:4] == exponent;
            wire cancel_terms = hit0 && hit1 && (code[3] != code[7]);
            wire hit = code != 8'd0 && (hit0 || hit1) && !cancel_terms;
            wire negative = hit0 ? code[3] : code[7];
            wire [8:0] signed_x = negative ? -x : x;
            // At most a 2:1 choice of x and fixed 2*x for duplicate exponents.
            // No exponent selects any shifted activation bus.
            wire [9:0] magnitude = hit0 && hit1 ? {signed_x,1'b0} : {signed_x[8],signed_x};
            assign contribution = hit ? magnitude : 10'd0;
            assign feedback = first_step ? 17'd0 : {product[15:0],1'b0};
        end
        reg [3:0] destination;
        assign wb_id[lane*4 +: 4] = destination;
        // The completed product itself is the registered WB data.
        assign wb_data[lane*32 +: 32] = {{15{product[16]}},product};
        always @(posedge clock or negedge reset_n) begin
            if (!reset_n) begin
                destination <= 0;
                product <= 0;
            end else if (issue) begin
                product <= feedback + {{7{contribution[9]}},contribution};
                if (final_step) begin
                    if (LANES == 4) destination <= {group_index,2'b00} | LANE_ID;
                    else if (LANES == 8) destination <= {group_index[0],3'b000} | LANE_ID;
                    else destination <= LANE_ID;
                end
            end
        end
    end endgenerate
endmodule
