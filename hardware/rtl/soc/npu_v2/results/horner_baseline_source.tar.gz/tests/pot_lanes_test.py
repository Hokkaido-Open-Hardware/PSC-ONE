import os
import cocotb
from cocotb.triggers import Timer
from pot import decode
from exponent_schedule import horner

@cocotb.test()
async def exhaustive_all_activation_code_pairs(dut):
    lanes=int(os.environ['LANES'])
    serial=int(os.environ.get('SERIAL_TERMS','0'))
    async def tick(**values):
        dut.clock.value=0
        for key,val in values.items():getattr(dut,key).value=val
        await Timer(5,unit='ns');dut.clock.value=1;await Timer(5,unit='ns')
    await tick(reset_n=0,capture=0,issue=0,phase=0,exponent=7,group_index=0,signed_mode=0,data_A=0,data_B=0)
    await tick(reset_n=1)
    for mode in (0,1):
        for base in range(0,65536,16):
            a=[(base+i)//256 for i in range(16)]
            b=[(base+i)%256 for i in range(16)]
            await tick(capture=1,issue=0,signed_mode=mode,data_A=sum(v<<(8*i) for i,v in enumerate(a)),data_B=sum(v<<(8*i) for i,v in enumerate(b)))
            assert int(dut.wb_valid.value)==0
            traces=[horner(x-(256 if mode and x&128 else 0),c,serial)[1] for x,c in zip(a,b)]
            for group in range(16//lanes):
                step=0
                for exponent in range(7,-1,-1):
                    for phase in range(2 if serial else 1):
                        await tick(capture=0,issue=1,phase=phase,exponent=exponent,group_index=group,data_A=0,data_B=0)
                        final=exponent==0 and (not serial or phase==1)
                        assert int(dut.wb_valid.value)==((1<<lanes)-1 if final else 0)
                        for lane in range(lanes):
                            index=group*lanes+lane
                            assert (int(dut.wb_data.value)>>(32*lane))&0xffffffff==traces[index][step]&0xffffffff
                            if final:
                                x=a[index]-(256 if mode and a[index]&128 else 0)
                                assert traces[index][step]==x*decode(b[index])
                                assert (int(dut.wb_id.value)>>(4*lane))&15==index
                        step+=1
                # Periodic issue stalls must retain product and invalidate WB.
                if base%256==0:
                    saved=int(dut.wb_data.value)
                    await tick(issue=0)
                    assert int(dut.wb_data.value)==saved and int(dut.wb_valid.value)==0
    await tick(issue=0)
    assert int(dut.wb_valid.value)==0
