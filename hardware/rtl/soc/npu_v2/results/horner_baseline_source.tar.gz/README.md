# PSC-NPU v2: 2-Term Power-of-Two 評価

> 現在の採用RTLは **4 lane・8-phase Horner方式**です。以下の旧selector方式の記録を保存し、末尾の「追記：8:1 selector除去実験」に新しい結果・再現手順をまとめています。


Tang Nano 20K上で乗算器を2項のshift/addへ置き換える独立実験。
既存 `../npu_v1`、CPU、OS、既存Makefile、SoCのNPU選択は変更していない。
製品統合やFPGA実機試験は行っていない。

測定結果: 演算用MULT9X9を4個削減したが、LUTが増えFmaxが低下した。
8 laneで同一clock時のv1 throughputを回復できるものの、DSP不足がない用途で
v1を置き換える優位性は確認できなかった。末尾にnextpnrの全比較を記載する。

## 既存npu_v1の解析

`../npu_v1/src` は Controller、ReadController、SystolicArray4x4、
MACScheduler、Mul4、AccBank の6モジュール。4x4は論理配置であり、
16個の乗算器を持つsystolic arrayではない。

- A（activation）は左から右、B（weight）は上から下へ、各128bitの
  shift contextを移動する。start E0、alignment E1、E2でA/Bとsigned modeをsnapshot。
- Mul4は4個のsigned 9x9乗算（INT8/UINT8共用）を持つ。
  lane nはACC ID n, n+4, n+8, n+12を担当する。
- E3～E6に4組のWBを登録、E4～E7に16 ACCを更新、E8にdone。
  WBはvalid、destination、32bit data。ACCは32bit wrap、各ACCの接続laneは固定。
  busy中にもACCは逐次変化し、Controllerはdone後に読む。
- ControllerはA=Y×X、B=X×Y、C=Y×Yを4×4 tileで処理する。
  X/Yは非ゼロの4の倍数。ReadControllerは32bit read request/response、
  Controllerは32bit C write request/responseとbackpressureを扱う。
  Controllerのdoneはstate resetまで保持され、内部MACのdoneは1クロックpulse。
- 公開APIは `software/os/src/synap_api.h` の `sa_run` / `sa_run_checked`。
  MMIO controlは0x10005000、既定入力0x00020000、結果0x00030000。
  CSRはCTRL=0x7C0、MODE=0x7C4、STATUS=0x7C8、A/B/C=0x7D0/0x7D4/0x7D8。
  CSR/MMIOデコードはNPU Controllerの外側にある。
- 既存cocotbは `hardware/sim/cocotb_tb/npu` にあり、
  `Makefile.npu validate_streaming` と `run_streaming_validation.py` で検証する。
  既存テストはINT8のBを期待するので、v2には独立したcode対応テストを用意した。
- 既存timing flowは `hardware/sim/Makefile.nextpnr.npu`。
  `PSC_NPU_TimingTop.sv` の登録済みpseudo stimulusとkeep信号でController全体を残し、
  `synth_gowin -family gw2a` → nextpnr-himbaechelを実行する。
  本比較もこの既存wrapper/CSTをそのまま使用する。

## 変更対象・構造・リスク

```text
Controller（v1から複製、LANES parameterの伝播のみ）
  ReadController（v1と同一）
  SystolicArray4x4（既存A/B routing、ポート、clear契約を維持）
    MACScheduler（2相、LANES=4/8/16）
    PotLanes（snapshot → 固定配線選択 → 符号処理 → 登録済みWB）
    AccBank（16×32bit、entry % LANESへ固定接続）
```

公開module名とポートをv1に合わせた。v1/v2の同名moduleを同時コンパイルしないこと。
LANESは4/8/16をサポート、既定値4。ControllerとSAのdimension契約は同じ。
BのバイトはINT8値ではなく以下のcodeになるため、既存softwareはそのまま使えない。
signed_modeはAのsigned/unsignedを選ぶ。Bは常に符号付き2項codeとして解釈する。

lane nの担当ACCは n, n+LANES, ... 。同じgroupを2クロック維持し、
phase 0で項0、phase 1で項1をWBへ登録する。次のedgeでACCに加算する。
各laneで同じ選択・符号処理回路を2項に時分割し、16個のACC加算器は維持した。
WBのdata registerは16bit、ACCへ符号拡張して渡す。
UINT8 activation 255でも各項±32640で16bitに収まる。

| startをE0としたedge | v1 4 lane | v2 4 lane | v2 8 lane | v2 16 lane |
|---|---:|---:|---:|---:|
| snapshot | E2 | E2 | E2 | E2 |
| WB登録 | E3–E6 | E3–E10 | E3–E6 | E3–E4 |
| 最終ACC更新 | E7 | E11 | E7 | E5 |
| done | E8 | E12 | E8 | E6 |
| 最短の次start | E9 | E13 | E9 | E7 |
| issue区間のweight/clk | 4 | 2 | 4 | 8 |

clearはidle時のみACCへ作用し、startより優先する。busy中のstart/ACC clearは無視。
SAのA/B shift registerはv1同様busy中もshift/clearに反応するが、snapshotは保護される。
resetは進行中のWBを破棄する。ACCは飽和せず32bit wrapする。

リスクは量子化精度、2相によるlatency増加、lane増加時のMUX/ALU増加、
メモリ転送律速によるlane増加効果の縮小。
アドレス生成の乗算は比較条件を揃えるためv1から保持した。
「INT8演算用乗算器ゼロ」と「Controller全体のDSPゼロ」は異なる。

## Weight codeと全探索

```text
bit [2:0] shift0 = 0..7     bit [3] sign0（1なら負）
bit [6:4] shift1 = 0..7     bit [7] sign1（1なら負）
code != 0: w' = (-1)^sign0 * 2^shift0 + (-1)^sign1 * 2^shift1
code == 0: w' = 0 （両phaseともゼロ）
```

0x00を特別なゼロとし、既存のゼロpadding/clearを維持する。
本来0x00が表す+2は+4−2等の別codeで表せるので表現集合は減らない。
等大反対符号のcodeもゼロになるが、encoderは0x00を選ぶ。
全codeをdecoderが扱い、INT8範囲外の復号値（最大±256）も定義される。
INT8を量子化したcanonical codeと任意のbyte codeは区別する。

`reference/pot.py` は全256 codeを各INT8値について探索し、絶対誤差最小を選ぶ。
同誤差なら復号値の絶対値が小さい方、次にbyte値が小さい方を選ぶ。
独立した符号×指数の全組合せ探索でも最小性を確認する。
指数8以上の2項からINT8範囲内に新たな非ゼロ値は作れないため、指数0～7で十分。

| 対象 | MAE | RMSE | 最大誤差 |
|---|---:|---:|---:|
| 全INT8 −128～127、指数0～7 | 1.75 | 2.663409469 | 8 |
| 比較: 指数0～6に制限 | 3.0859375 | 5.038135816 | 16 |

88/256値は完全一致、168値が変化する。
全値の元weight、code、復号weight、absolute errorは
[results/int8_quantization.csv](results/int8_quantization.csv)。

RTLはxを16bitへ符号/ゼロ拡張し、`x`, `x<<1`, ... `x<<7`相当の
constant concatenationをcase選択する。可変shift演算子は使わない。
Yosysのgeneric netlistも監査する。`$shiftx`はgroupのoperand slice選択であり、
activationを可変桁シフトするbarrel shifterではない。

## TFLite CPU比較

対象は現行の非ゼロ推論fixture
`software/os/tests/tflite/build/tflite-model/phase3/MODEL.TFL`。
一つ上の `MODEL.TFL` は全重みゼロのparser/FAT32 fixtureなので使用しない。
モデルのSHA256を [results/model_evaluation.json](results/model_evaluation.json) に記録した。

既存 `tflite_demo.h` の入力と全20ch golden（FC1 16ch＋FC2 4ch）を使用。
加えて全要素−128/−1/0/1/127の5入力、固定seedのランダム256入力、合計262入力。
20chは20サンプルの意味ではなく、既存参照の出力channel数。

`model_probe.cc` は実際のTFLite bytesを既存PSC CPU runtimeに読み込ませ、
raw dot、zero-point補正、bias加算、requant、clampを全channelで取得する。
Python側はその全段階と完全一致することを確認してからweightを置換する。
TFLiteのdouble rounding、scale、bias、fused ReLUは維持する。
zero-point補正のrow sumには量子化後weightを使う。

| 比較対象 | 数 | MAE / 最大誤差 |
|---|---:|---:|
| FC1 weight | 256 | 0 / 0 |
| FC2 weight | 64 | 0 / 0 |
| FC1 ACC・output | 4192 channel | 0 / 0 |
| FC2 ACC・output | 1048 channel | 0 / 0 |
| final output | 262×4 | 0 / 0 |
| classification（最初の最大値のindex） | 262入力 | 262/262一致 |

既存入力のfinal outputは両方式とも `[-36, 27, 18, 8]`、class indexは1（0始まり）。
全320 weightは小さい整数で、今回のcodeで全て誤差ゼロになる。
これは合成検証用の未学習モデルであり、実データに対する分類精度は評価できない。
学習済みモデル／正解ラベル付きデータセットによる精度評価は今後の課題。

全weightの比較は [results/model_weights.csv](results/model_weights.csv)、
全入力・全channelの比較は [results/model_comparison.csv](results/model_comparison.csv)。

## 検証

- 各lane構成で全activation 256値×全code 256値×signed/unsigned 2 mode。
  各項のWB data/ID、2項の和、snapshot、validをPython参照と比較。
- 各edgeのACC更新とphase、300回のidle bubbleなし連続実行、busy中start/clear、
  E2でのmode capture、全途中edgeでのreset、done/busyのタイミング。
- 32bit ACC overflow、clear優先、誤ったlane/IDの拒否を2000 transactionで確認。
- Controllerは4×4、8×4、4×8、12×20、20×12とread/write遅延・backpressure。
  全C値・アドレス・転送数を独立Python行列積と比較。
- 各lane構成でTFLite全262入力×20chの積を直接datapathで検証。
- さらに実Controllerのメモリ転送とK方向ACCを用いて全262入力×20chを計算。
  RTL FC1 → Pythonで既存requant/clamp → RTL FC2の順で実行し、
  全raw dot・bias加算後ACC・requant・FC1/FC2 output・argmaxがCPUと完全一致。
- v1の既存SA契約、Controller cycle、Mul4網羅、AccBankテストを独立buildで回帰。

cocotb結果: v2は18 testcase、v1回帰は5 testcase、全23 testcase PASS、FAIL/SKIP=0。
Icarus elaboration、Yosys合成、Verilator lintもPASS。Verilatorにはv1から引き継いだ
Controllerの比較幅warningと、新parameter式の比較/ID切り詰め幅warningが残る。
後者はLANES=4/8/16でgroup 0..3、ID 0..15の範囲内であり、網羅試験でも確認した。

CPU/OS/SoCの選択を変更しないため、CPU設計変更用RISC-V/core/OS長時間回帰は対象外。

## 再現手順（repository root）

既存myenvのcocotb 2.0.1、Icarus、g++、同梱TFLite vendor、Yosys、nextpnrを使用する。
ネットワークからの依存追加は不要。runnerはcleanを呼ばず、出力先のみ作成する。

```bash
python3 PSC-ONE/hardware/rtl/soc/npu_v2/reference/pot.py \
  --output PSC-ONE/hardware/rtl/soc/npu_v2/results
python3 PSC-ONE/hardware/rtl/soc/npu_v2/reference/evaluate_model.py \
  --build /tmp/psc-npu-v2-model
myenv/bin/python PSC-ONE/hardware/rtl/soc/npu_v2/tests/run.py \
  --build /tmp/psc-npu-v2-tests \
  --vectors /tmp/psc-npu-v2-model/rtl_vectors.json \
  --case lanes core controller bank
myenv/bin/python PSC-ONE/hardware/rtl/soc/npu_v2/tests/run.py \
  --build /tmp/psc-npu-v2-full-model \
  --vectors /tmp/psc-npu-v2-model/rtl_vectors.json --case model_controller
python3 PSC-ONE/hardware/rtl/soc/npu_v2/tests/synthesis.py \
  --build /tmp/psc-npu-v2-timing
myenv/bin/python PSC-ONE/hardware/sim/cocotb_tb/npu/run_streaming_validation.py \
  --build /tmp/psc-npu-v2-v1-regression \
  --case controller_cycles,mul4,acc_bank,sa_contract
```

モデルが未生成のcheckoutでは、先に以下でfixture/reference.csvを生成すること。

```bash
python3 PSC-ONE/software/os/tests/tflite/generate_model.py \
  --build PSC-ONE/software/os/tests/tflite/build/tflite-model/phase3
```

既存モデルを評価対象として保存し、
別の学習済みモデルに対応する際はinput/channel制約も変更して明示する。


## 成果物と残課題

新規ファイルはすべて本 `npu_v2/` 配下:

- `src/`: 上記6個のRTL module（Mul4の代わりにPotLanes）。
- `reference/`: pot.py、evaluate_model.py、model_probe.cc。
- `tests/`: CoreTop.sv、bank/core/controller/model_controller/pot_lanes各test、
  run.py、synthesis.py、report.py。
- `results/`: quantization/model CSV/JSON、Controller cycle比較、cocotb結果、
  synthesis比較JSON/Markdown、12 runのcritical path。
- README.md、.gitignore。

既存ファイルの変更・削除なし。npu_v1とCPU/OS/Makefileも変更なし。
Git状態は `?? PSC-ONE/hardware/rtl/soc/npu_v2/` のみ。
add/commit/push等、Git状態を変更する操作は行っていない。

モデル生成物・full log・netlist・PNR JSONは `/tmp/psc-npu-v2-model`、
`/tmp/psc-npu-v2-tests`、`/tmp/psc-npu-v2-full-model`、
`/tmp/psc-npu-v2-v1-regression`、`/tmp/psc-npu-v2-timing` に保存。
16 laneのoperand選択式を切り分ける補助合成は `/tmp/psc-npu-v2-select-probe` に保存。
単一groupを直接配線にしてもMUX増加は解消せず、採用RTLは変更しなかった。
一時ファイルも削除していない。

結果の再収集は以下。`--model-tests`には追加のControllerモデル試験を実行したbuildを指定する。
`run.py`の既定では全testを同じbuildに置くので、再実行時は両引数にそのbuildを指定し、
集計はtest名で分類して重複を除く。

```bash
python3 PSC-ONE/hardware/rtl/soc/npu_v2/tests/report.py \
  --timing /tmp/psc-npu-v2-timing \
  --tests /tmp/psc-npu-v2-tests \
  --model-tests /tmp/psc-npu-v2-full-model \
  --baseline /tmp/psc-npu-v2-v1-regression
```

残課題: 学習済みモデルの分類精度、SoC統合後のtiming/帯域/実測電力、FPGA実機検証。
PoTが本質的に不利という一般結論ではなく、現実装・現toolchainの比較結果である。
符号処理をshift前の狭い幅へ移す等の最適化は今回の採用RTLには含めていない。

## nextpnr測定結果

全構成で同じ既存Controller wrapper/CST、GW2AR-LV18QN88C8/I7、GW2A-18C、
81 MHz制約、seed 1/2/3。`--timing-allow-fail`は違反時にも測定値を残すために指定。
合否は81 MHz制約に対して別途判定した。今回12 runは全てPASS。
SoC全体ではなく、pseudo stimulusを含むNPU Controller単体の配置配線結果。

| 構成 | LUT4 (pnr, seed 1) | FF | MULT9X9 | MUX | ALU (pnr) | Fmax中央値 MHz | 3 seed範囲 MHz |
|---|---:|---:|---:|---:|---:|---:|---|
| v1 | 2769 | 1679 | 7 | 265 | 820 | 202.72 | 192.38–214.13 |
| v2_4 | 3482 | 1677 | 3 | 841 | 886 | 129.43 | 117.76–129.85 |
| v2_8 | 3473 | 1740 | 3 | 340 | 952 | 131.49 | 126.55–133.28 |
| v2_16 | 8504 | 1867 | 3 | 4446 | 1076 | 120.54 | 117.65–120.77 |

LUT4はnextpnrのpacked utilization値。ALU/MUXは別resource種別の報告であり、
単純合計してFPGA面積とはしない。FF/MULT/MUXも同じnextpnr reportから取得。
LUT以外の表中resource数は3 seedで同一。MULT18X18/ALU54D/BSRAMは全て0。
LUT4の3 seed範囲: v1=2769–2771、v2_4=3477–3482、v2_8=3465–3473、v2_16=8499–8504。
MULT9X9はプリミティブ数であり物理DSP macroの占有ブロック数とは異なる。
v1の7個中4個がINT8演算用、残り3個はアドレス用。v2の演算部は0個。

| 構成 | Yosys LUT1–4計 | FF | MUX | ALU | 演算部のみ MULT9X9 |
|---|---:|---:|---:|---:|---:|
| v1 | 2145 | 1679 | 265 | 762 | 4 |
| v2_4 | 2905 | 1677 | 841 | 823 | 0 |
| v2_8 | 2926 | 1740 | 340 | 884 | 0 |
| v2_16 | 7935 | 1867 | 4446 | 1002 | 0 |

nextpnrはpacking時にALU等を変換するためYosysのLUT/ALU数と異なる。

| 構成 | seed 1 Fmax | seed 2 Fmax | seed 3 Fmax | 最遅seedのlogic + routing ns |
|---|---:|---:|---:|---|
| v1 | 202.72 | 214.13 | 192.38 | 1.76 + 3.44 |
| v2_4 | 129.43 | 129.85 | 117.76 | 4.00 + 4.49 |
| v2_8 | 131.49 | 133.28 | 126.55 | 3.94 + 3.96 |
| v2_16 | 117.65 | 120.77 | 120.54 | 3.99 + 4.51 |

v1のcritical pathはController制御からwriteback register enable等へ至る経路。
v2はPoT laneのoperand/phase/shift選択と符号反転を経てWBへ至る経路が律速。
厳密な始点・終点はJSON、各段の論理/配線遅延は `critical_*_seed*.txt` に保存。

| X × Y / memory delay | v1 cycles | v2 4 cycles | v2 8 cycles | v2 16 cycles |
|---|---:|---:|---:|---:|
| 4 × 4 / 1 (signed=0) | 214 | 262 | 214 | 190 |
| 4 × 4 / 1 (signed=1) | 214 | 262 | 214 | 190 |
| 8 × 4 / 1 (signed=1) | 394 | 490 | 394 | 346 |
| 4 × 8 / 5 (signed=0) | 1280 | 1470 | 1280 | 1181 |
| 12 × 20 / 5 (signed=0) | 18624 | 22189 | 18624 | 16794 |
| 20 × 12 / 5 (signed=1) | 10509 | 12669 | 10509 | 9429 |

8 laneで2clk/weightのissue throughputとController cycle数をv1まで回復。
16 laneは同一81 MHzで約8～12%のController cycle削減に留まり、転送と制御が残る。
各設計のFmaxで動かす仮定では、代表4×4 (delay=1) の実行時間は次のとおり。

| 構成 | cycles / Fmax中央値 (µs) | 81 MHzでの時間 (µs) |
|---|---:|---:|
| v1 | 1.056 | 2.642 |
| v2_4 | 2.024 | 3.235 |
| v2_8 | 1.628 | 2.642 |
| v2_16 | 1.576 | 2.346 |

結論: 本実装・本mapping条件ではDSPを4個削減できる一方、LUT/MUX増加と
Fmax低下が大きい。DSPの不足がないTang Nano 20K用途でv1を置き換える優位性は確認できない。
DSPを他用途へ確保し、81 MHz固定で使う場合は8 laneが候補だが、面積は増加する。
16 laneはMUX増加が特に大きく、今回の速度改善に対して費用が大きい。
汎用barrel shifterはないが、固定8択selectもmapping後のコストは無視できない。
最大Fmaxは単体wrapperの推定値であり、SoC統合後や実機の保証周波数ではない。

## 追記：8:1 selector除去実験（4演算ブロックで比較）

以下が現在の採用RTL。上のselector方式の測定値は履歴としてそのまま保存した。
主比較は **v1の4 MUL、旧v2の4 selector lane、新v2の4 Horner lane**。
8/16 laneの旧表と混ぜない。新規npu_v3は作成せず、変更はnpu_v2配下に限定した。

### Python評価と方式選定

weight byteは変更せず、従来の8bit canonical codeをそのまま受け付ける。
現在の符号化ではゼロ以外は2項を格納する。単一PoTも同指数2項や隣接指数差で表されるため、
格納された項数と、数学的に簡約した最小項数の両方を集計した。

| 対象 | weight数 | 格納0/1/2項 | 簡約後0/1/2項 | exponent-majorの格納項数 | 簡約後項数 |
|---|---:|---|---|---:|---:|
| all_INT8 | 256 | 1/0/255 | 1/15/240 | 510 | 495 |
| unique_canonical | 88 | 1/0/87 | 1/15/72 | 174 | 159 |
| FC1 | 256 | 17/0/239 | 17/103/136 | 478 | 375 |
| FC2 | 64 | 5/0/59 | 5/30/29 | 118 | 88 |
| model_all | 320 | 22/0/298 | 22/133/165 | 596 | 463 |

並べ替えだけでは項数は減らない。簡約は別の変換であり採用RTLではencodingを変更しない。
all_INT8は元の−128～127を各1回量子化した分布、unique_canonicalは重複codeを除いた88種類。

| exponent | 全INT8 positive | 全INT8 negative | 現モデル positive | 現モデル negative |
|---|---:|---:|---:|---:|
| 0 | 13 | 11 | 104 | 61 |
| 1 | 19 | 14 | 154 | 44 |
| 2 | 28 | 21 | 89 | 65 |
| 3 | 41 | 30 | 17 | 62 |
| 4 | 55 | 35 | 0 | 0 |
| 5 | 60 | 22 | 0 | 0 |
| 6 | 52 | 46 | 0 | 0 |
| 7 | 23 | 40 | 0 | 0 |

モデルのzero weight率は22/320=6.875%。8-phase Hornerの寄与ゼロ率は77.578125%、
全INT8では75.390625%。2項を別phaseにする16-phaseではskip率は各88.359375%/87.548828125%。
**skipは加える寄与が0という意味で、clockを省略する意味ではない。**
Hornerはその指数の寄与が0でも固定倍化を行う必要がある。
モデルは指数0～3だけを使うが、採用実装はモデル依存にせず毎回7→0を走査する。

現在のweight encodingは8bitのまま。項ごとにvalidを追加すると10bit、簡約済みternary planeは16bit、
未簡約の±2係数も含むplaneは24bit/weight。疎なFC1 bucketは少なくとも1項あたり
sign 1 + input index 4 + output index 4 = 9bitが必要で、bucket pointer/countは別途必要。
理想的な4 lane sparse発行は全INT8 131 cycles、FC1 121 cycles、FC2 32 cycles。
これはdestination競合・転送・最終reduceを無視した下限で、今回の実装cycleではない。

| 案 | 追加状態・回路 | 判断 |
|---|---|---|
| exponent別ACC | 16出力×8指数×32bit=4096bitの一時ACC、固定shift後のwide reduction | 状態量と最終加算が大きい |
| 固定shift WB | 指数ごとの固定経路を並列に置くとwide出力選択/加算が必要。1bit反復ならcycle増 | selector移設を避けるため不採用 |
| 既存ACC全体のHorner | 過去のK tileの累積値まで倍になる。全K再走査か退避ACCが必要 | Controller/read変更を避ける |
| lane内Horner16 | 17bit部分積、1項ずつ±x/skip、feedbackのhold/double選択 | 合成して比較 |
| lane内Horner8 | 17bit部分積、同指数を合算した0/±x/±2x、feedbackは常に固定倍化 | 4 laneで最小だったため採用 |

| 4 lane候補、Yosys合成 | LUT1–4計 | FF | MUX | ALU |
|---|---:|---:|---:|---:|
| horner8 | 2263 | 1683 | 119 | 865 |
| horner16 | 2821 | 1684 | 740 | 869 |

8 laneの予備検討後、ユーザー指定に従い4 laneで選定をやり直した。
上表は4 laneの候補比較であり、全候補をFPGAで実測した最適解の主張ではない。
SERIAL_TERMS=0（既定）が採用8-phase、=1が比較用16-phase。既定LANES=4。

### 採用構造とnetlist確認

Schedulerが各groupについてexponentを7→0へ進め、laneは指数一致を比較するだけ。
coef_k = Σ(sign_t | shift_t == k)、p_next = 2*p + coef_k*x。
同指数・同符号なら±2x、反対符号なら0になる。2xと2pはconstant concatenationで実装した。
17bitの部分積はsigned/unsigned activationと全256 byte codeの範囲（最大±65280）を保持できる。
最初の指数で部分積を0から開始し、exponent 0の完了後だけ既存32bit ACCへ加算する。
16 ACCは変更せず、過去の積和を倍化しない。A/B転送・snapshot契約・MMIO・8bit weight codeも維持する。

| 16 MAC batch / 4 lane | v1 | 旧v2 selector | 新v2 Horner8 | 比較Horner16 |
|---|---:|---:|---:|---:|
| issue clocks | 4 | 8 | 32 | 64 |
| start E0からdoneまで | 8 | 12 | 36 | 68 |
| 最短start間隔 | 9 | 13 | 37 | 69 |
| issue中のweight/clock | 4 | 2 | 0.5 | 0.25 |

新Horner8のWBはE10/E18/E26/E34、ACC更新はE11/E19/E27/E35、doneはE36。
zero/clear/reset/back-to-backとbusy中のsnapshot保護を検証した。

合成前generic netlistとController全体をflattenしたnetlistを両方監査した。
演算部の `$mul/$shl/$shr/$sshl/$sshr/$pmux` は全て0。
旧版の16bit×8択 `$pmux` は消え、weightがshift済みactivationを選ぶ経路はない。
残る `$shiftx` はA/B contextの4:1選択（入力幅32bit以下）に限る。
merged係数にはx/固定2xの2:1選択が残るが、指数別8候補の選択ではない。
Schedulerも監査し、ACC/ReadControllerはbaselineとbyte一致、Controller本体は
compile-time parameter伝播以外一致を確認した。既存の16 ACC read選択などは残っているため、
「NPU全体に大きなMUXが一切ない」という意味ではない。selectorの別階層への移設はない。

### 同条件nextpnr、4演算ブロック比較

既存wrapper/CST、GW2AR-LV18QN88C8/I7、GW2A-18C、81 MHz、seed 1/2/3。
tool versionとwrapper hashも旧測定と一致。v1は今回再実行、旧v2は保存済み結果を使用した。
LUTはseed 1、Fmaxは3 seed中央値。その他のresource数は3 seedで同一。

| 構成 | LUT4 | FF | MULT9X9 | MUX | ALU | Fmax中央値 MHz |
|---|---:|---:|---:|---:|---:|---:|
| v1_4mul | 2769 | 1679 | 7 | 265 | 820 | 202.72 |
| selector_v2_4 | 3482 | 1677 | 3 | 841 | 886 | 129.43 |
| horner_v2_4 | 2795 | 1683 | 3 | 119 | 936 | 124.78 |

MULT9X9はprimitive数。v1は演算4＋アドレス3、旧/新v2は演算0＋アドレス3。
ALU/MUXは別resource種別であり、LUTと単純合算して面積とはしない。

| 構成 | Fmax seed 1 / 2 / 3 MHz | LUT4の範囲 | 最遅seed logic + routing ns |
|---|---|---|---|
| v1_4mul | 202.72 / 214.13 / 192.38 | 2769–2771 | 1.76 + 3.44 |
| selector_v2_4 | 129.43 / 129.85 / 117.76 | 3477–3482 | 4.00 + 4.49 |
| horner_v2_4 | 124.78 / 127.15 / 120.42 | 2793–2795 | 4.76 + 3.54 |

新方式のcritical pathは snapshot → context/係数/符号処理 → **17bit Horner加算のcarry chain**
→ 部分積レジスタ。旧shift selectorを除去しても、この直列経路が新しい律速になった。
詳細な始点・終点・全段の遅延は比較JSONとcritical_*.txtに保存。

| X×Y / delay | v1 cycles / µs@81MHz | 旧v2 cycles / µs | 新Horner cycles / µs |
|---|---:|---:|---:|
| 4×4 / 1 (signed=0) | 214 / 2.642 | 262 / 3.235 | 550 / 6.790 |
| 4×4 / 1 (signed=1) | 214 / 2.642 | 262 / 3.235 | 550 / 6.790 |
| 8×4 / 1 (signed=1) | 394 / 4.864 | 490 / 6.049 | 1066 / 13.160 |
| 4×8 / 5 (signed=0) | 1280 / 15.802 | 1470 / 18.148 | 2621 / 32.358 |
| 12×20 / 5 (signed=0) | 18624 / 229.926 | 22189 / 273.938 | 43794 / 540.667 |
| 20×12 / 5 (signed=1) | 10509 / 129.741 | 12669 / 156.407 | 25629 / 316.407 |

新規6 run（v1/new各3 seed）は全て81 MHz制約PASS。旧v2の保存済み3 runもPASS。
FmaxはNPU単体wrapperの推定値であり、SoC統合後や実機の保証周波数ではない。

### 判断

1. 8:1 activation shift selectorの除去: **達成**。他階層へ移していない。
2. 旧v2からのLUT削減: **達成**。3482→2795（−19.7%）、MUX 841→119（−85.9%）。
3. Fmax回復: **未達**。旧v2 129.43→新124.78 MHz、v1は202.72 MHz。
4. throughputとの釣り合い: 4×4で旧v2の262→550 cycles（約2.10倍）。約20%のLUT削減に対して性能損失が大きい。
5. v1への利点: 演算MULT9X9を4個空けられる。ただしLUT4は2769→2795とほぼ同じで、
   4×4は214→550 cycles（約2.57倍）。DSPが特に不足する場合以外、置き換える明確な総合利点は確認できない。

追加の最適化は行わず、17bit Horner加算を新しいボトルネックとして記録する。
電力は測定していない。実モデルの精度・実機・SoC統合は今回の結論の対象外。

### 検証・保存先

Pythonは全activation×全256 code×signed/unsigned×Horner2方式、262144比較PASS。
採用4 laneの5 unit/Controller testcase＋TFLite全体1 testcase、v1回帰5 testcaseが全PASS。
比較用Horner16も4 laneの網羅・core・Controller計4 testcaseがPASS。
signed/unsigned、canonical全88 codeに加えて全256 code、各途中Horner値、±256復号値、
ACC wrap、zero、reset全途中edge、clear、300回back-to-back、matrix/backpressureを含む。
TFLiteは全262入力×20ch=5240 channelをController経由で実行し、
FC1のRTL結果をrequantしてFC2へ渡し、全ACC/requant/output/argmaxがCPUと一致した。
weight変換は旧方式と同じであり、現在の検証用モデルの最終出力も `[-36,27,18,8]`、class=1。
学習済みモデルの分類精度を示す結果ではない。
Verilator lintは終了コード0。既存Controllerの幅warningと定数parameter幅warningは残る。

旧ソース・README・測定結果42ファイルを `results/selector_baseline_source.tar.gz` に保存し、
`selector_baseline_manifest.json` にSHA256を記録した。既存resultsのCSV/JSON/critical pathは上書きしていない。
今回の詳細は `results/selectorless/`、full log/netlistは以下のbuild先。

```bash
python3 PSC-ONE/hardware/rtl/soc/npu_v2/reference/exponent_schedule.py \
  --model-json /tmp/psc-npu-v2-model/model.json \
  --output PSC-ONE/hardware/rtl/soc/npu_v2/results/selectorless
myenv/bin/python PSC-ONE/hardware/rtl/soc/npu_v2/tests/run.py \
  --build /tmp/psc-npu-v2-horner4-check --lanes 4 \
  --vectors /tmp/psc-npu-v2-model/rtl_vectors.json
python3 PSC-ONE/hardware/rtl/soc/npu_v2/tests/synthesis.py \
  --build /tmp/psc-npu-v2-horner4-timing --variants v1 v2_4
```

モデルJSON/CPU trace/vectorがない場合は `reference/evaluate_model.py` を
旧READMEの手順で実行する。上のcheckは全採用testを同一buildにまとめて再実行する手順。
今回の既存実行先はunit=`/tmp/psc-npu-v2-horner-tests`（主比較は末尾4のcase）、
full model=`/tmp/psc-npu-v2-horner4-full-model`、v1=`/tmp/psc-npu-v2-horner4-v1-tests`、
候補面積=`/tmp/psc-npu-v2-horner8-lane4-area`と`/tmp/psc-npu-v2-horner16-lane4-area`。
4 laneへの指定前に走った8/16 laneのunit試験もPASSしたが、主比較の測定値には使用していない。
netlist監査の初回エラーはYosysのescaped階層名の照合ミスであり、RTL不一致ではなかった。
階層名を正規化して再合成・監査しPASSした。

変更: srcのPotLanes/MACScheduler/SystolicArray4x4/Controller、testsのCoreTop/core/pot_lanes/run/synthesis、README。
新規: reference/exponent_schedule.py、tests/selectorless_report.py、baseline archive/manifest、results/selectorless。
削除なし。npu/npu_v1、CPU、OS、SoC、既存Makefileは変更なし。Git add/commit/push等も未実施。
