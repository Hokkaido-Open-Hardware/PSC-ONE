# PSC-NPU v2: 2-Term Power-of-Two 評価

Tang Nano 20K上で乗算器を2項のshift/addへ置き換える独立実験。
既存 `../npu_v1`、CPU、OS、既存Makefile、SoCのNPU選択は変更していない。
製品統合やFPGA実機試験は行っていない。

測定結果: 演算用MULT9X9を4個削減したが、LUTが増えFmaxが低下した。
8 laneで同一clock時のv1 throughputを回復できるものの、DSP不足がない用途で
v1を置き換える優位性は確認できなかった。末尾にnextpnrの全比較を記載する。

## 既存npu_v1の解析

`../npu_v1/src` は Controller、ReadController、SystolicArray4x4、
MACScheduler、Mul4、AccBank の6モジュール。4x4は論理配置であり、
16個の乗算器を持つsystolic arrayではない。

- A（activation）は左から右、B（weight）は上から下へ、各128bitの
  shift contextを移動する。start E0、alignment E1、E2でA/Bとsigned modeをsnapshot。
- Mul4は4個のsigned 9x9乗算（INT8/UINT8共用）を持つ。
  lane nはACC ID n, n+4, n+8, n+12を担当する。
- E3～E6に4組のWBを登録、E4～E7に16 ACCを更新、E8にdone。
  WBはvalid、destination、32bit data。ACCは32bit wrap、各ACCの接続laneは固定。
  busy中にもACCは逐次変化し、Controllerはdone後に読む。
- ControllerはA=Y×X、B=X×Y、C=Y×Yを4×4 tileで処理する。
  X/Yは非ゼロの4の倍数。ReadControllerは32bit read request/response、
  Controllerは32bit C write request/responseとbackpressureを扱う。
  Controllerのdoneはstate resetまで保持され、内部MACのdoneは1クロックpulse。
- 公開APIは `software/os/src/synap_api.h` の `sa_run` / `sa_run_checked`。
  MMIO controlは0x10005000、既定入力0x00020000、結果0x00030000。
  CSRはCTRL=0x7C0、MODE=0x7C4、STATUS=0x7C8、A/B/C=0x7D0/0x7D4/0x7D8。
  CSR/MMIOデコードはNPU Controllerの外側にある。
- 既存cocotbは `hardware/sim/cocotb_tb/npu` にあり、
  `Makefile.npu validate_streaming` と `run_streaming_validation.py` で検証する。
  既存テストはINT8のBを期待するので、v2には独立したcode対応テストを用意した。
- 既存timing flowは `hardware/sim/Makefile.nextpnr.npu`。
  `PSC_NPU_TimingTop.sv` の登録済みpseudo stimulusとkeep信号でController全体を残し、
  `synth_gowin -family gw2a` → nextpnr-himbaechelを実行する。
  本比較もこの既存wrapper/CSTをそのまま使用する。

## 変更対象・構造・リスク

```text
Controller（v1から複製、LANES parameterの伝播のみ）
  ReadController（v1と同一）
  SystolicArray4x4（既存A/B routing、ポート、clear契約を維持）
    MACScheduler（2相、LANES=4/8/16）
    PotLanes（snapshot → 固定配線選択 → 符号処理 → 登録済みWB）
    AccBank（16×32bit、entry % LANESへ固定接続）
```

公開module名とポートをv1に合わせた。v1/v2の同名moduleを同時コンパイルしないこと。
LANESは4/8/16をサポート、既定値4。ControllerとSAのdimension契約は同じ。
BのバイトはINT8値ではなく以下のcodeになるため、既存softwareはそのまま使えない。
signed_modeはAのsigned/unsignedを選ぶ。Bは常に符号付き2項codeとして解釈する。

lane nの担当ACCは n, n+LANES, ... 。同じgroupを2クロック維持し、
phase 0で項0、phase 1で項1をWBへ登録する。次のedgeでACCに加算する。
各laneで同じ選択・符号処理回路を2項に時分割し、16個のACC加算器は維持した。
WBのdata registerは16bit、ACCへ符号拡張して渡す。
UINT8 activation 255でも各項±32640で16bitに収まる。

| startをE0としたedge | v1 4 lane | v2 4 lane | v2 8 lane | v2 16 lane |
|---|---:|---:|---:|---:|
| snapshot | E2 | E2 | E2 | E2 |
| WB登録 | E3–E6 | E3–E10 | E3–E6 | E3–E4 |
| 最終ACC更新 | E7 | E11 | E7 | E5 |
| done | E8 | E12 | E8 | E6 |
| 最短の次start | E9 | E13 | E9 | E7 |
| issue区間のweight/clk | 4 | 2 | 4 | 8 |

clearはidle時のみACCへ作用し、startより優先する。busy中のstart/ACC clearは無視。
SAのA/B shift registerはv1同様busy中もshift/clearに反応するが、snapshotは保護される。
resetは進行中のWBを破棄する。ACCは飽和せず32bit wrapする。

リスクは量子化精度、2相によるlatency増加、lane増加時のMUX/ALU増加、
メモリ転送律速によるlane増加効果の縮小。
アドレス生成の乗算は比較条件を揃えるためv1から保持した。
「INT8演算用乗算器ゼロ」と「Controller全体のDSPゼロ」は異なる。

## Weight codeと全探索

```text
bit [2:0] shift0 = 0..7     bit [3] sign0（1なら負）
bit [6:4] shift1 = 0..7     bit [7] sign1（1なら負）
code != 0: w' = (-1)^sign0 * 2^shift0 + (-1)^sign1 * 2^shift1
code == 0: w' = 0 （両phaseともゼロ）
```

0x00を特別なゼロとし、既存のゼロpadding/clearを維持する。
本来0x00が表す+2は+4−2等の別codeで表せるので表現集合は減らない。
等大反対符号のcodeもゼロになるが、encoderは0x00を選ぶ。
全codeをdecoderが扱い、INT8範囲外の復号値（最大±256）も定義される。
INT8を量子化したcanonical codeと任意のbyte codeは区別する。

`reference/pot.py` は全256 codeを各INT8値について探索し、絶対誤差最小を選ぶ。
同誤差なら復号値の絶対値が小さい方、次にbyte値が小さい方を選ぶ。
独立した符号×指数の全組合せ探索でも最小性を確認する。
指数8以上の2項からINT8範囲内に新たな非ゼロ値は作れないため、指数0～7で十分。

| 対象 | MAE | RMSE | 最大誤差 |
|---|---:|---:|---:|
| 全INT8 −128～127、指数0～7 | 1.75 | 2.663409469 | 8 |
| 比較: 指数0～6に制限 | 3.0859375 | 5.038135816 | 16 |

88/256値は完全一致、168値が変化する。
全値の元weight、code、復号weight、absolute errorは
[results/int8_quantization.csv](results/int8_quantization.csv)。

RTLはxを16bitへ符号/ゼロ拡張し、`x`, `x<<1`, ... `x<<7`相当の
constant concatenationをcase選択する。可変shift演算子は使わない。
Yosysのgeneric netlistも監査する。`$shiftx`はgroupのoperand slice選択であり、
activationを可変桁シフトするbarrel shifterではない。

## TFLite CPU比較

対象は現行の非ゼロ推論fixture
`software/os/tests/tflite/build/tflite-model/phase3/MODEL.TFL`。
一つ上の `MODEL.TFL` は全重みゼロのparser/FAT32 fixtureなので使用しない。
モデルのSHA256を [results/model_evaluation.json](results/model_evaluation.json) に記録した。

既存 `tflite_demo.h` の入力と全20ch golden（FC1 16ch＋FC2 4ch）を使用。
加えて全要素−128/−1/0/1/127の5入力、固定seedのランダム256入力、合計262入力。
20chは20サンプルの意味ではなく、既存参照の出力channel数。

`model_probe.cc` は実際のTFLite bytesを既存PSC CPU runtimeに読み込ませ、
raw dot、zero-point補正、bias加算、requant、clampを全channelで取得する。
Python側はその全段階と完全一致することを確認してからweightを置換する。
TFLiteのdouble rounding、scale、bias、fused ReLUは維持する。
zero-point補正のrow sumには量子化後weightを使う。

| 比較対象 | 数 | MAE / 最大誤差 |
|---|---:|---:|
| FC1 weight | 256 | 0 / 0 |
| FC2 weight | 64 | 0 / 0 |
| FC1 ACC・output | 4192 channel | 0 / 0 |
| FC2 ACC・output | 1048 channel | 0 / 0 |
| final output | 262×4 | 0 / 0 |
| classification（最初の最大値のindex） | 262入力 | 262/262一致 |

既存入力のfinal outputは両方式とも `[-36, 27, 18, 8]`、class indexは1（0始まり）。
全320 weightは小さい整数で、今回のcodeで全て誤差ゼロになる。
これは合成検証用の未学習モデルであり、実データに対する分類精度は評価できない。
学習済みモデル／正解ラベル付きデータセットによる精度評価は今後の課題。

全weightの比較は [results/model_weights.csv](results/model_weights.csv)、
全入力・全channelの比較は [results/model_comparison.csv](results/model_comparison.csv)。

## 検証

- 各lane構成で全activation 256値×全code 256値×signed/unsigned 2 mode。
  各項のWB data/ID、2項の和、snapshot、validをPython参照と比較。
- 各edgeのACC更新とphase、300回のidle bubbleなし連続実行、busy中start/clear、
  E2でのmode capture、全途中edgeでのreset、done/busyのタイミング。
- 32bit ACC overflow、clear優先、誤ったlane/IDの拒否を2000 transactionで確認。
- Controllerは4×4、8×4、4×8、12×20、20×12とread/write遅延・backpressure。
  全C値・アドレス・転送数を独立Python行列積と比較。
- 各lane構成でTFLite全262入力×20chの積を直接datapathで検証。
- さらに実Controllerのメモリ転送とK方向ACCを用いて全262入力×20chを計算。
  RTL FC1 → Pythonで既存requant/clamp → RTL FC2の順で実行し、
  全raw dot・bias加算後ACC・requant・FC1/FC2 output・argmaxがCPUと完全一致。
- v1の既存SA契約、Controller cycle、Mul4網羅、AccBankテストを独立buildで回帰。

cocotb結果: v2は18 testcase、v1回帰は5 testcase、全23 testcase PASS、FAIL/SKIP=0。
Icarus elaboration、Yosys合成、Verilator lintもPASS。Verilatorにはv1から引き継いだ
Controllerの比較幅warningと、新parameter式の比較/ID切り詰め幅warningが残る。
後者はLANES=4/8/16でgroup 0..3、ID 0..15の範囲内であり、網羅試験でも確認した。

CPU/OS/SoCの選択を変更しないため、CPU設計変更用RISC-V/core/OS長時間回帰は対象外。

## 再現手順（repository root）

既存myenvのcocotb 2.0.1、Icarus、g++、同梱TFLite vendor、Yosys、nextpnrを使用する。
ネットワークからの依存追加は不要。runnerはcleanを呼ばず、出力先のみ作成する。

```bash
python3 PSC-ONE/hardware/rtl/soc/npu_v2/reference/pot.py \
  --output PSC-ONE/hardware/rtl/soc/npu_v2/results
python3 PSC-ONE/hardware/rtl/soc/npu_v2/reference/evaluate_model.py \
  --build /tmp/psc-npu-v2-model
myenv/bin/python PSC-ONE/hardware/rtl/soc/npu_v2/tests/run.py \
  --build /tmp/psc-npu-v2-tests \
  --vectors /tmp/psc-npu-v2-model/rtl_vectors.json \
  --case lanes core controller bank
myenv/bin/python PSC-ONE/hardware/rtl/soc/npu_v2/tests/run.py \
  --build /tmp/psc-npu-v2-full-model \
  --vectors /tmp/psc-npu-v2-model/rtl_vectors.json --case model_controller
python3 PSC-ONE/hardware/rtl/soc/npu_v2/tests/synthesis.py \
  --build /tmp/psc-npu-v2-timing
myenv/bin/python PSC-ONE/hardware/sim/cocotb_tb/npu/run_streaming_validation.py \
  --build /tmp/psc-npu-v2-v1-regression \
  --case controller_cycles,mul4,acc_bank,sa_contract
```

モデルが未生成のcheckoutでは、先に以下でfixture/reference.csvを生成すること。

```bash
python3 PSC-ONE/software/os/tests/tflite/generate_model.py \
  --build PSC-ONE/software/os/tests/tflite/build/tflite-model/phase3
```

既存モデルを評価対象として保存し、
別の学習済みモデルに対応する際はinput/channel制約も変更して明示する。


## 成果物と残課題

新規ファイルはすべて本 `npu_v2/` 配下:

- `src/`: 上記6個のRTL module（Mul4の代わりにPotLanes）。
- `reference/`: pot.py、evaluate_model.py、model_probe.cc。
- `tests/`: CoreTop.sv、bank/core/controller/model_controller/pot_lanes各test、
  run.py、synthesis.py、report.py。
- `results/`: quantization/model CSV/JSON、Controller cycle比較、cocotb結果、
  synthesis比較JSON/Markdown、12 runのcritical path。
- README.md、.gitignore。

既存ファイルの変更・削除なし。npu_v1とCPU/OS/Makefileも変更なし。
Git状態は `?? PSC-ONE/hardware/rtl/soc/npu_v2/` のみ。
add/commit/push等、Git状態を変更する操作は行っていない。

モデル生成物・full log・netlist・PNR JSONは `/tmp/psc-npu-v2-model`、
`/tmp/psc-npu-v2-tests`、`/tmp/psc-npu-v2-full-model`、
`/tmp/psc-npu-v2-v1-regression`、`/tmp/psc-npu-v2-timing` に保存。
16 laneのoperand選択式を切り分ける補助合成は `/tmp/psc-npu-v2-select-probe` に保存。
単一groupを直接配線にしてもMUX増加は解消せず、採用RTLは変更しなかった。
一時ファイルも削除していない。

結果の再収集は以下。`--model-tests`には追加のControllerモデル試験を実行したbuildを指定する。
`run.py`の既定では全testを同じbuildに置くので、再実行時は両引数にそのbuildを指定し、
集計はtest名で分類して重複を除く。

```bash
python3 PSC-ONE/hardware/rtl/soc/npu_v2/tests/report.py \
  --timing /tmp/psc-npu-v2-timing \
  --tests /tmp/psc-npu-v2-tests \
  --model-tests /tmp/psc-npu-v2-full-model \
  --baseline /tmp/psc-npu-v2-v1-regression
```

残課題: 学習済みモデルの分類精度、SoC統合後のtiming/帯域/実測電力、FPGA実機検証。
PoTが本質的に不利という一般結論ではなく、現実装・現toolchainの比較結果である。
符号処理をshift前の狭い幅へ移す等の最適化は今回の採用RTLには含めていない。

## nextpnr測定結果

全構成で同じ既存Controller wrapper/CST、GW2AR-LV18QN88C8/I7、GW2A-18C、
81 MHz制約、seed 1/2/3。`--timing-allow-fail`は違反時にも測定値を残すために指定。
合否は81 MHz制約に対して別途判定した。今回12 runは全てPASS。
SoC全体ではなく、pseudo stimulusを含むNPU Controller単体の配置配線結果。

| 構成 | LUT4 (pnr, seed 1) | FF | MULT9X9 | MUX | ALU (pnr) | Fmax中央値 MHz | 3 seed範囲 MHz |
|---|---:|---:|---:|---:|---:|---:|---|
| v1 | 2769 | 1679 | 7 | 265 | 820 | 202.72 | 192.38–214.13 |
| v2_4 | 3482 | 1677 | 3 | 841 | 886 | 129.43 | 117.76–129.85 |
| v2_8 | 3473 | 1740 | 3 | 340 | 952 | 131.49 | 126.55–133.28 |
| v2_16 | 8504 | 1867 | 3 | 4446 | 1076 | 120.54 | 117.65–120.77 |

LUT4はnextpnrのpacked utilization値。ALU/MUXは別resource種別の報告であり、
単純合計してFPGA面積とはしない。FF/MULT/MUXも同じnextpnr reportから取得。
LUT以外の表中resource数は3 seedで同一。MULT18X18/ALU54D/BSRAMは全て0。
LUT4の3 seed範囲: v1=2769–2771、v2_4=3477–3482、v2_8=3465–3473、v2_16=8499–8504。
MULT9X9はプリミティブ数であり物理DSP macroの占有ブロック数とは異なる。
v1の7個中4個がINT8演算用、残り3個はアドレス用。v2の演算部は0個。

| 構成 | Yosys LUT1–4計 | FF | MUX | ALU | 演算部のみ MULT9X9 |
|---|---:|---:|---:|---:|---:|
| v1 | 2145 | 1679 | 265 | 762 | 4 |
| v2_4 | 2905 | 1677 | 841 | 823 | 0 |
| v2_8 | 2926 | 1740 | 340 | 884 | 0 |
| v2_16 | 7935 | 1867 | 4446 | 1002 | 0 |

nextpnrはpacking時にALU等を変換するためYosysのLUT/ALU数と異なる。

| 構成 | seed 1 Fmax | seed 2 Fmax | seed 3 Fmax | 最遅seedのlogic + routing ns |
|---|---:|---:|---:|---|
| v1 | 202.72 | 214.13 | 192.38 | 1.76 + 3.44 |
| v2_4 | 129.43 | 129.85 | 117.76 | 4.00 + 4.49 |
| v2_8 | 131.49 | 133.28 | 126.55 | 3.94 + 3.96 |
| v2_16 | 117.65 | 120.77 | 120.54 | 3.99 + 4.51 |

v1のcritical pathはController制御からwriteback register enable等へ至る経路。
v2はPoT laneのoperand/phase/shift選択と符号反転を経てWBへ至る経路が律速。
厳密な始点・終点はJSON、各段の論理/配線遅延は `critical_*_seed*.txt` に保存。

| X × Y / memory delay | v1 cycles | v2 4 cycles | v2 8 cycles | v2 16 cycles |
|---|---:|---:|---:|---:|
| 4 × 4 / 1 (signed=0) | 214 | 262 | 214 | 190 |
| 4 × 4 / 1 (signed=1) | 214 | 262 | 214 | 190 |
| 8 × 4 / 1 (signed=1) | 394 | 490 | 394 | 346 |
| 4 × 8 / 5 (signed=0) | 1280 | 1470 | 1280 | 1181 |
| 12 × 20 / 5 (signed=0) | 18624 | 22189 | 18624 | 16794 |
| 20 × 12 / 5 (signed=1) | 10509 | 12669 | 10509 | 9429 |

8 laneで2clk/weightのissue throughputとController cycle数をv1まで回復。
16 laneは同一81 MHzで約8～12%のController cycle削減に留まり、転送と制御が残る。
各設計のFmaxで動かす仮定では、代表4×4 (delay=1) の実行時間は次のとおり。

| 構成 | cycles / Fmax中央値 (µs) | 81 MHzでの時間 (µs) |
|---|---:|---:|
| v1 | 1.056 | 2.642 |
| v2_4 | 2.024 | 3.235 |
| v2_8 | 1.628 | 2.642 |
| v2_16 | 1.576 | 2.346 |

結論: 本実装・本mapping条件ではDSPを4個削減できる一方、LUT/MUX増加と
Fmax低下が大きい。DSPの不足がないTang Nano 20K用途でv1を置き換える優位性は確認できない。
DSPを他用途へ確保し、81 MHz固定で使う場合は8 laneが候補だが、面積は増加する。
16 laneはMUX増加が特に大きく、今回の速度改善に対して費用が大きい。
汎用barrel shifterはないが、固定8択selectもmapping後のコストは無視できない。
最大Fmaxは単体wrapperの推定値であり、SoC統合後や実機の保証周波数ではない。
