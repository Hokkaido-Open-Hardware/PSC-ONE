#!/usr/bin/env python3
"""Shared8 full NPU and a common arithmetic-only timing wrapper; no cleanup."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE=Path(__file__).resolve().parents[1]
ROOT=BASE.parents[4]
SIM=ROOT/'PSC-ONE/hardware/sim'
WRAPPER=ROOT/'PSC-ONE/hardware/rtl/tang20k/timing/PSC_NPU_TimingTop.sv'


def execute(command,log):
    with log.open('w') as out:
        subprocess.run(list(map(str,command)),stdout=out,stderr=subprocess.STDOUT,check=True)


def counts(path,top):
    cells=json.loads(path.read_text())['modules'][top]['cells']
    c=Counter(x['type'] for x in cells.values())
    return {'cells':dict(c),'LUT':sum(c[f'LUT{i}'] for i in range(1,5)),
            'FF':sum(v for k,v in c.items() if k.startswith('DFF')),
            'MUX':sum(v for k,v in c.items() if k.startswith('MUX2_LUT')),
            'ALU':c['ALU'],'MULT9X9':c['MULT9X9'],'MULT18X18':c['MULT18X18']}


def instances(modules,name,target):
    total=0
    for c in modules[name].get('cells',{}).values():
        if c['type']==target:total+=1
        elif c['type'] in modules:total+=instances(modules,c['type'],target)
    return total


def main():
    p=argparse.ArgumentParser();p.add_argument('--build',type=Path,required=True)
    p.add_argument('--seeds',type=int,nargs='+',default=[1,2,3])
    p.add_argument('--variants',nargs='+',choices=['v1','shared8','mul4','shiftadd4','shiftadd8'],
                   default=['v1','shared8','mul4','shiftadd4','shiftadd8'])
    p.add_argument('--synth-only',action='store_true')
    a=p.parse_args();a.build=a.build.resolve();a.build.mkdir(parents=True,exist_ok=True)
    yosys=SIM/'yosys/build/yosys'
    result={'device':'GW2AR-LV18QN88C8/I7','family':'GW2A-18C','target_MHz':81,
            'yosys':subprocess.check_output([str(yosys),'-V'],text=True).strip(),
            'nextpnr':subprocess.check_output(['nextpnr-himbaechel','--version'],text=True,stderr=subprocess.STDOUT).strip(),
            'wrapper_sha256':hashlib.sha256(WRAPPER.read_bytes()).hexdigest(),
            'datapath_wrapper_sha256':hashlib.sha256((BASE/'tests/DatapathTiming.sv').read_bytes()).hexdigest(),
            'cst_sha256':hashlib.sha256(WRAPPER.with_suffix('.cst').read_bytes()).hexdigest(),'variants':{}}
    for variant in a.variants:
        build=a.build/variant;build.mkdir(parents=True,exist_ok=True)
        unit=variant in ['mul4','shiftadd4','shiftadd8']
        blocks=8 if variant in ['shared8','shiftadd8'] else 4
        shiftadd=variant in ['shared8','shiftadd4','shiftadd8']
        if unit:
            top='PSC_NPU_DatapathTiming'
            files=[BASE/'tests/DatapathTiming.sv',BASE/'src/PSC_NPU_ShiftAdd2.sv']
            config=f'chparam -set BLOCKS {blocks} -set KIND {int(shiftadd)} {top}; '
        else:
            top='PSC_NPU_Timing'
            src=BASE.parent/'npu_v1/src' if variant=='v1' else BASE/'src'
            files=[WRAPPER,*sorted(src.glob('*.*v'))]
            config=''
        read='read_verilog -sv '+' '.join(map(str,files))+'; '+config+f'hierarchy -check -top {top}; '
        # Exact same full-NPU flow as both previous experiments.
        (build/'synth.ys').write_text(read+f'flatten; synth_gowin -top {top} -family gw2a -json {build}/npu.json; stat\n')
        execute([yosys,'-s',build/'synth.ys'],build/'yosys.log')
        summary=counts(build/'npu.json',top)
        summary.update({'top':top,'scope':'arithmetic_only' if unit else 'full_controller','blocks':blocks,
                        'source_sha256':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}})
        # Separate generic audit leaves the measured synthesis flow unchanged.
        script=read+f'proc; opt; write_json {build}/hierarchy.json; flatten; opt; write_json {build}/generic.json'
        (build/'audit.ys').write_text(script+'\n')
        execute([yosys,'-s',build/'audit.ys'],build/'audit.log')
        modules=json.loads((build/'hierarchy.json').read_text())['modules']
        actual_blocks=instances(modules,top,'PSC_NPU_ShiftAdd2')
        assert actual_blocks==(blocks if shiftadd else 0)
        generic=json.loads((build/'generic.json').read_text())['modules'][top]['cells']
        summary['generic_cells']=dict(Counter(c['type'] for c in generic.values()))
        summary['shiftadd_instances']=actual_blocks
        if shiftadd:
            assert not any(c['type'] == '$shiftx' for c in generic.values())
            dynamic_shifts = [c for c in generic.values()
                if c['type'] in ['$shl', '$shr', '$sshl', '$sshr', '$shift']
                and any(isinstance(bit, int) for bit in c['connections']['B'])]
            assert not dynamic_shifts
            summary['packed_read_audit'] = {'status': 'PASS', 'shiftx_cells': 0,
                                            'variable_shift_cells': 0}
        if shiftadd:
            cells=modules['PSC_NPU_ShiftAdd2']['cells']
            types=Counter(c['type'] for c in cells.values())
            assert not any(types[k] for k in ['$mul','$shl','$shr','$sshl','$sshr','$shiftx'])
            assert not any('dff' in k.lower() for k in types)
            selectors=[c for c in cells.values() if c['type']=='$pmux']
            assert len(selectors)==2
            assert all(int(c['parameters']['WIDTH'],2)==16 and int(c['parameters']['S_WIDTH'],2)==8 for c in selectors)
            assert types['$add']==1 and types['$neg']==2
            summary['block_audit']={'status':'PASS','generic_cells':dict(types),
                'shift_selection':'two 16-bit 8-choice fixed-candidate muxes per block',
                'no_variable_shift':True,'no_state_or_accumulator':True}
            assert summary['MULT9X9']==(0 if unit else 3)
        else:
            assert summary['MULT9X9']==(4 if unit else 7)
        summary['pnr']=[];result['variants'][variant]=summary
        (a.build/'synthesis_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
        print(variant,'synth',{k:summary[k] for k in ['LUT','FF','MUX','ALU','MULT9X9','shiftadd_instances']},flush=True)
        for seed in ([] if a.synth_only else a.seeds):
            report=build/f'timing_seed{seed}.json';log=build/f'pnr_seed{seed}.log'
            cmd=['nextpnr-himbaechel','--json',build/'npu.json','--write',build/f'pnr_seed{seed}.json',
                 '--device',result['device'],'--vopt','family='+result['family'],
                 '--vopt','cst='+str(WRAPPER.with_suffix('.cst')),'--freq','81','--seed',seed,
                 '--timing-allow-fail','--report',report]
            execute(cmd,log)
            raw=json.loads(report.read_text());text=log.read_text()
            fmax=min(c['achieved'] for c in raw['fmax'].values())
            path=raw['critical_paths'][0]
            routing=sum(x['delay'] for x in path['path'] if x['type']=='routing')
            logic=sum(x['delay'] for x in path['path'] if x['type']!='routing')
            starts=[m.start() for m in re.finditer(r'Info: Critical path report for clock',text)]
            critical=text[starts[-1]:] if starts else ''
            end=critical.find('Info: Max frequency')
            if end>=0:critical=critical[:end]
            (build/f'critical_seed{seed}.txt').write_text(critical)
            item={'seed':seed,'fmax_MHz':fmax,'pass_81MHz':fmax>=81,'logic_ns':logic,'routing_ns':routing,
                  'utilization':raw['utilization'],'critical_path':path}
            summary['pnr'].append(item)
            (a.build/'synthesis_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
            print(variant,{k:round(v,3) if isinstance(v,float) else v for k,v in item.items() if k not in ['utilization','critical_path']},flush=True)
    print('Artifacts:',a.build,flush=True)

if __name__=='__main__':main()
