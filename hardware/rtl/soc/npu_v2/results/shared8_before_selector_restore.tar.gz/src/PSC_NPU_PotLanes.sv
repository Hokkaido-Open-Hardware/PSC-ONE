`timescale 1ns/1ps

// Exactly eight physical blocks, each shared by adjacent PE IDs 2*j,2*j+1.
// phase=0 issues the even PE; phase=1 issues the odd PE. Each issue is a
// COMPLETE two-term product, never a term phase or a Horner step.
module PSC_NPU_PotLanes #(parameter integer LANES = 8) (
    input wire clock, reset_n, capture, issue, phase,
    input wire signed_mode,
    input wire [127:0] data_A, data_B,
    output reg [LANES-1:0] wb_valid,
    output wire [LANES*4-1:0] wb_id,
    output wire [LANES*32-1:0] wb_data
);
    reg [127:0] a_snapshot, b_snapshot;
    reg wb_phase;
    always @(posedge clock or negedge reset_n) begin
        if (!reset_n) begin
            a_snapshot <= 0;
            b_snapshot <= 0;
            wb_valid <= 0;
            wb_phase <= 0;
        end else begin
            if (capture) begin
                a_snapshot <= data_A;
                b_snapshot <= data_B;
            end
            wb_valid <= {LANES{issue}};
            if (issue) wb_phase <= phase;
        end
    end
    genvar lane;
    generate for (lane=0; lane<LANES; lane=lane+1) begin : GEN_LANE
        localparam [2:0] PAIR_ID = lane;
        wire [7:0] a = phase ? a_snapshot[(2*lane+1)*8 +: 8] : a_snapshot[(2*lane)*8 +: 8];
        wire [7:0] code = phase ? b_snapshot[(2*lane+1)*8 +: 8] : b_snapshot[(2*lane)*8 +: 8];
        wire [16:0] product;
        PSC_NPU_ShiftAdd2 u_shiftadd (
            .activation(a), .weight_code(code), .signed_mode(signed_mode),
            .product(product)
        );
        reg [16:0] data;
        assign wb_id[lane*4 +: 4] = {PAIR_ID,wb_phase};
        assign wb_data[lane*32 +: 32] = {{15{data[16]}},data};
        always @(posedge clock or negedge reset_n) begin
            if (!reset_n) data <= 0;
            else if (issue) data <= product;
        end
    end endgenerate
    `ifdef NPU_ASSERTIONS
    initial if (LANES != 8) $fatal(1,"Shared adjacent-PE architecture requires exactly eight blocks");
    `endif
endmodule
